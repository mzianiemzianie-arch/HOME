import { useState, useMemo, useEffect } from "react";
import { products, categories, type Product } from "./data/products";

function formatPrice(n: number) {
  if (n === 0) return "السعر عند الطلب";
  return n.toLocaleString("fr-DZ") + " د.ج";
}

const WILAYAS = [
  "أدرار","الشلف","الأغواط","أم البواقي","باتنة","بجاية","بسكرة","بشار","البليدة","البويرة",
  "تمنراست","تبسة","تلمسان","تيارت","تيزي وزو","الجزائر","الجلفة","جيجل","سطيف","سعيدة",
  "سكيكدة","سيدي بلعباس","عنابة","قالمة","قسنطينة","المدية","مستغانم","المسيلة","معسكر","ورقلة",
  "وهران","البيض","إليزي","برج بوعريريج","بومرداس","الطارف","تندوف","تيسمسيلت","الوادي","خنشلة",
  "سوق أهراس","تيبازة","ميلة","عين الدفلى","النعامة","عين تموشنت","غرداية","غليزان","تيميمون","برج باجي مختار",
  "أولاد جلال","بني عباس","عين صالح","عين قزام","تقرت","جانت","المغير","المنيعة"
];

const WHATSAPP_NUMBER = "213559093125";

interface CartItem extends Product {
  quantity: number;
}

export default function App() {
  const [selectedCategory, setSelectedCategory] = useState("الكل");
  const [searchTerm, setSearchTerm] = useState("");
  const [sortBy, setSortBy] = useState<"default" | "price-asc" | "price-desc">("default");
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [orderProduct, setOrderProduct] = useState<Product | null>(null);
  const [quickViewProduct, setQuickViewProduct] = useState<Product | null>(null);
  const [scrolled, setScrolled] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const t = setTimeout(() => setIsLoading(false), 800);
    const onScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener("scroll", onScroll);
    return () => {
      clearTimeout(t);
      window.removeEventListener("scroll", onScroll);
    };
  }, []);

  // lock body scroll when modals open
  useEffect(() => {
    if (isCartOpen || orderProduct || quickViewProduct || isMenuOpen) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "";
    }
  }, [isCartOpen, orderProduct, quickViewProduct, isMenuOpen]);

  const filteredProducts = useMemo(() => {
    let list = products;
    if (selectedCategory !== "الكل") {
      list = list.filter((p) =>
        selectedCategory === "Promotion" ? p.onSale : p.category === selectedCategory
      );
    }
    if (searchTerm.trim()) {
      const q = searchTerm.toLowerCase();
      list = list.filter((p) => p.name.toLowerCase().includes(q));
    }
    if (sortBy === "price-asc") list = [...list].sort((a, b) => a.price - b.price);
    if (sortBy === "price-desc") list = [...list].sort((a, b) => b.price - a.price);
    return list;
  }, [selectedCategory, searchTerm, sortBy]);

  const promoProducts = useMemo(() => products.filter((p) => p.onSale).slice(0, 8), []);
  const featuredProducts = useMemo(() => products.slice(0, 4), []);

  const addToCart = (p: Product) => {
    setCart((c) => {
      const existing = c.find((x) => x.id === p.id);
      if (existing) {
        return c.map((x) => (x.id === p.id ? { ...x, quantity: x.quantity + 1 } : x));
      }
      return [...c, { ...p, quantity: 1 }];
    });
  };

  const removeFromCart = (id: number) => {
    setCart((c) => c.filter((x) => x.id !== id));
  };

  const updateQty = (id: number, qty: number) => {
    if (qty < 1) return removeFromCart(id);
    setCart((c) => c.map((x) => (x.id === id ? { ...x, quantity: qty } : x)));
  };

  const cartTotal = cart.reduce((s, p) => s + p.price * p.quantity, 0);
  const cartCount = cart.reduce((s, p) => s + p.quantity, 0);

  if (isLoading) {
    return (
      <div className="fixed inset-0 bg-gradient-to-br from-[#0a0a0a] via-[#1a0f1a] to-[#0a0a0a] flex items-center justify-center z-50">
        <div className="text-center">
          <div className="relative">
            <div className="w-24 h-24 border-4 border-amber-500/20 rounded-full"></div>
            <div className="absolute inset-0 w-24 h-24 border-4 border-transparent border-t-amber-500 rounded-full animate-spin"></div>
          </div>
          <h1 className="mt-6 text-3xl font-bold tracking-[0.3em] bg-gradient-to-r from-amber-300 via-amber-500 to-amber-700 bg-clip-text text-transparent">
            VELORIA
          </h1>
          <p className="text-amber-200/60 text-sm tracking-[0.4em] mt-1">HOME</p>
        </div>
      </div>
    );
  }

  return (
    <div dir="rtl" className="min-h-screen bg-[#fafaf7] text-stone-800 font-sans selection:bg-amber-200">
      {/* Top announcement bar */}
      <div className="bg-gradient-to-r from-[#1a0f1a] via-[#2a1810] to-[#1a0f1a] text-amber-100 text-xs md:text-sm py-2 px-4 text-center font-medium tracking-wide overflow-hidden">
        <div className="animate-marquee whitespace-nowrap inline-block">
          ✨ توصيل سريع لكل ولايات الجزائر 58 • 🎁 هدايا مجانية مع العروض • 💎 ضمان أصلي على جميع المنتجات • 📞 اتصل بنا: 0559093125 ✨
        </div>
      </div>

      {/* Header */}
      <header
        className={`sticky top-0 z-40 transition-all duration-500 ${
          scrolled
            ? "bg-white/95 backdrop-blur-xl shadow-lg shadow-amber-900/5"
            : "bg-white/80 backdrop-blur-md"
        } border-b border-amber-100`}
      >
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <button
              className="lg:hidden p-2 rounded-lg hover:bg-amber-50 transition"
              onClick={() => setIsMenuOpen(true)}
            >
              <svg width="24" height="24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M3 6h18M3 12h18M3 18h18" />
              </svg>
            </button>

            {/* Luxury Logo */}
            <a href="#" className="flex items-center gap-3 group">
              <div className="relative">
                <div className="w-11 h-11 md:w-12 md:h-12 rounded-full bg-gradient-to-br from-amber-400 via-amber-600 to-amber-800 flex items-center justify-center shadow-lg shadow-amber-500/30 group-hover:scale-105 transition">
                  <span className="text-white font-serif text-xl font-bold">V</span>
                </div>
                <div className="absolute inset-0 rounded-full ring-2 ring-amber-400/30 ring-offset-2 ring-offset-white"></div>
              </div>
              <div className="flex flex-col">
                <h1 className="text-lg md:text-2xl font-serif font-bold tracking-[0.25em] bg-gradient-to-r from-stone-800 via-amber-700 to-stone-800 bg-clip-text text-transparent">
                  VELORIA
                </h1>
                <p className="text-[10px] md:text-xs tracking-[0.5em] text-amber-700 -mt-1 font-light">
                  HOME
                </p>
              </div>
            </a>
          </div>

          {/* Desktop Nav */}
          <nav className="hidden lg:flex items-center gap-8">
            {["الرئيسية", "المنتجات", "العروض", "اتصل بنا"].map((item, i) => (
              <a
                key={i}
                href={i === 1 ? "#products" : i === 2 ? "#promo" : "#"}
                onClick={(e) => {
                  if (i === 2) {
                    e.preventDefault();
                    setSelectedCategory("Promotion");
                    document.getElementById("products")?.scrollIntoView({ behavior: "smooth" });
                  }
                }}
                className="text-sm font-medium text-stone-700 hover:text-amber-700 transition relative group"
              >
                {item}
                <span className="absolute -bottom-1 right-0 w-0 h-0.5 bg-gradient-to-l from-amber-600 to-amber-400 group-hover:w-full transition-all duration-300"></span>
              </a>
            ))}
          </nav>

          <div className="flex items-center gap-2 md:gap-3">
            {/* Search */}
            <div className="hidden md:block relative">
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="ابحث..."
                className="w-48 lg:w-64 px-4 py-2 pr-10 rounded-full bg-stone-50 border border-stone-200 focus:border-amber-400 focus:ring-2 focus:ring-amber-100 outline-none transition text-sm"
              />
              <svg className="absolute right-3 top-2.5 text-stone-400" width="18" height="18" fill="none" stroke="currentColor" strokeWidth="2">
                <circle cx="9" cy="9" r="7" />
                <path d="m20 20-6-6" />
              </svg>
            </div>

            <a
              href={`https://wa.me/${WHATSAPP_NUMBER}`}
              target="_blank"
              rel="noreferrer"
              className="hidden md:flex p-2.5 rounded-full bg-green-500 hover:bg-green-600 text-white transition shadow-md"
              aria-label="واتساب"
            >
              <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.297-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
              </svg>
            </a>

            <button
              onClick={() => setIsCartOpen(true)}
              className="relative p-2.5 rounded-full bg-gradient-to-br from-stone-900 to-stone-700 hover:from-amber-700 hover:to-amber-900 text-white transition shadow-md group"
            >
              <svg width="20" height="20" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M3 3h2l2 13h12l2-8H6" />
                <circle cx="9" cy="20" r="1.5" />
                <circle cx="17" cy="20" r="1.5" />
              </svg>
              {cartCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-amber-500 text-white text-[10px] font-bold rounded-full w-5 h-5 flex items-center justify-center ring-2 ring-white animate-bounce">
                  {cartCount}
                </span>
              )}
            </button>
          </div>
        </div>

        {/* Mobile search */}
        <div className="md:hidden px-4 pb-3">
          <div className="relative">
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="ابحث عن منتج..."
              className="w-full px-4 py-2 pr-10 rounded-full bg-stone-50 border border-stone-200 focus:border-amber-400 outline-none text-sm"
            />
            <svg className="absolute right-3 top-2.5 text-stone-400" width="18" height="18" fill="none" stroke="currentColor" strokeWidth="2">
              <circle cx="9" cy="9" r="7" />
              <path d="m20 20-6-6" />
            </svg>
          </div>
        </div>
      </header>

      {/* Hero Section - Luxury */}
      <section className="relative overflow-hidden bg-gradient-to-br from-[#1a0f1a] via-[#2a1810] to-[#0f0a0f] text-white">
        {/* Decorative elements */}
        <div className="absolute inset-0">
          <div className="absolute top-20 right-10 w-96 h-96 bg-amber-500/20 rounded-full blur-[120px]"></div>
          <div className="absolute bottom-20 left-10 w-[500px] h-[500px] bg-amber-700/10 rounded-full blur-[150px]"></div>
          <div className="absolute inset-0 opacity-[0.03]" style={{
            backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='60' height='60' viewBox='0 0 60 60'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='1'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
          }}></div>
        </div>

        <div className="relative max-w-7xl mx-auto px-4 py-20 md:py-32">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="text-center lg:text-right">
              <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs tracking-[0.3em] mb-6">
                <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse"></span>
                مجموعة 2026 الفاخرة
              </div>

              <h2 className="text-5xl md:text-7xl font-serif font-bold mb-6 leading-tight">
                <span className="block bg-gradient-to-r from-white via-amber-100 to-white bg-clip-text text-transparent">
                  أناقة فاخرة
                </span>
                <span className="block mt-2 bg-gradient-to-r from-amber-300 via-amber-500 to-amber-700 bg-clip-text text-transparent">
                  لمنزل استثنائي
                </span>
              </h2>

              <p className="text-lg md:text-xl text-stone-300 mb-8 leading-relaxed max-w-xl mx-auto lg:mx-0">
                اكتشف مجموعتنا الحصرية من المنتجات الفاخرة. جودة لا تضاهى، تصميم راقي، وأسعار استثنائية.
              </p>

              <div className="flex flex-wrap gap-4 justify-center lg:justify-start">
                <a
                  href="#products"
                  className="group relative px-8 py-4 rounded-full bg-gradient-to-r from-amber-500 to-amber-700 text-white font-semibold tracking-wider text-sm overflow-hidden shadow-2xl shadow-amber-900/50 hover:shadow-amber-500/50 transition-all hover:scale-105"
                >
                  <span className="relative z-10">اكتشف المجموعة</span>
                  <div className="absolute inset-0 bg-gradient-to-r from-amber-600 to-amber-800 opacity-0 group-hover:opacity-100 transition"></div>
                </a>
                <button
                  onClick={() => {
                    setSelectedCategory("Promotion");
                    document.getElementById("products")?.scrollIntoView({ behavior: "smooth" });
                  }}
                  className="px-8 py-4 rounded-full border-2 border-amber-400/40 text-amber-300 hover:bg-amber-400/10 font-semibold tracking-wider text-sm transition"
                >
                  العروض الحصرية ✨
                </button>
              </div>

              <div className="grid grid-cols-3 gap-6 mt-12 max-w-md mx-auto lg:mx-0">
                <div className="text-center">
                  <div className="text-3xl md:text-4xl font-serif font-bold bg-gradient-to-b from-amber-300 to-amber-600 bg-clip-text text-transparent">70+</div>
                  <div className="text-xs text-stone-400 mt-1 tracking-wider">منتج فاخر</div>
                </div>
                <div className="text-center border-x border-amber-500/20">
                  <div className="text-3xl md:text-4xl font-serif font-bold bg-gradient-to-b from-amber-300 to-amber-600 bg-clip-text text-transparent">58</div>
                  <div className="text-xs text-stone-400 mt-1 tracking-wider">ولاية</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl md:text-4xl font-serif font-bold bg-gradient-to-b from-amber-300 to-amber-600 bg-clip-text text-transparent">5★</div>
                  <div className="text-xs text-stone-400 mt-1 tracking-wider">تقييم العملاء</div>
                </div>
              </div>
            </div>

            {/* Hero featured product display */}
            <div className="relative hidden lg:block">
              <div className="relative">
                <div className="absolute -inset-4 bg-gradient-to-r from-amber-500/30 to-amber-700/30 blur-2xl rounded-full"></div>
                <div className="relative grid grid-cols-2 gap-4">
                  {featuredProducts.slice(0, 4).map((p, i) => (
                    <div
                      key={p.id}
                      className={`relative bg-white/5 backdrop-blur-xl rounded-2xl overflow-hidden border border-amber-500/20 group cursor-pointer hover:border-amber-400/60 transition-all ${
                        i === 0 ? "row-span-2" : ""
                      }`}
                      onClick={() => setQuickViewProduct(p)}
                    >
                      <div className={`overflow-hidden ${i === 0 ? "aspect-[3/4]" : "aspect-square"}`}>
                        <img
                          src={p.image}
                          alt={p.name}
                          className="w-full h-full object-cover group-hover:scale-110 transition duration-700"
                        />
                      </div>
                      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition flex items-end p-3">
                        <div className="text-white text-xs font-medium line-clamp-2">{p.name}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom wave */}
        <svg className="absolute bottom-0 left-0 right-0 w-full" viewBox="0 0 1440 80" preserveAspectRatio="none">
          <path fill="#fafaf7" d="M0,32L60,37.3C120,43,240,53,360,53.3C480,53,600,43,720,42.7C840,43,960,53,1080,53.3C1200,53,1320,43,1380,37.3L1440,32L1440,80L1380,80C1320,80,1200,80,1080,80C960,80,840,80,720,80C600,80,480,80,360,80C240,80,120,80,60,80L0,80Z"></path>
        </svg>
      </section>

      {/* Features bar */}
      <section className="bg-white border-y border-stone-100">
        <div className="max-w-7xl mx-auto px-4 py-8 grid grid-cols-2 md:grid-cols-4 gap-6">
          {[
            { icon: "🚚", t: "توصيل سريع", d: "لكل ولايات الجزائر" },
            { icon: "💎", t: "جودة فاخرة", d: "منتجات أصلية 100%" },
            { icon: "💳", t: "دفع آمن", d: "عند الاستلام" },
            { icon: "📞", t: "دعم متواصل", d: "خدمة عملاء VIP" },
          ].map((s, i) => (
            <div key={i} className="flex items-center gap-3 group">
              <div className="text-3xl md:text-4xl">{s.icon}</div>
              <div>
                <div className="font-bold text-stone-800 text-sm md:text-base">{s.t}</div>
                <div className="text-xs text-stone-500">{s.d}</div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Promotions Carousel */}
      <section id="promo" className="max-w-7xl mx-auto px-4 py-16">
        <div className="text-center mb-12">
          <p className="text-amber-700 text-xs tracking-[0.4em] mb-2">EXCLUSIVE OFFERS</p>
          <h3 className="text-3xl md:text-5xl font-serif font-bold text-stone-800">
            العروض <span className="text-amber-700">الحصرية</span>
          </h3>
          <div className="flex items-center justify-center gap-3 mt-4">
            <div className="w-12 h-px bg-gradient-to-r from-transparent to-amber-500"></div>
            <div className="w-2 h-2 rounded-full bg-amber-500"></div>
            <div className="w-12 h-px bg-gradient-to-l from-transparent to-amber-500"></div>
          </div>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
          {promoProducts.map((p) => (
            <ProductCard
              key={p.id}
              product={p}
              onAddToCart={addToCart}
              onBuyNow={(p) => setOrderProduct(p)}
              onQuickView={(p) => setQuickViewProduct(p)}
            />
          ))}
        </div>
      </section>

      {/* Products Section */}
      <section id="products" className="bg-gradient-to-b from-stone-50 to-white py-16">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-12">
            <p className="text-amber-700 text-xs tracking-[0.4em] mb-2">OUR COLLECTION</p>
            <h3 className="text-3xl md:text-5xl font-serif font-bold text-stone-800">
              مجموعتنا <span className="text-amber-700">الكاملة</span>
            </h3>
            <div className="flex items-center justify-center gap-3 mt-4">
              <div className="w-12 h-px bg-gradient-to-r from-transparent to-amber-500"></div>
              <div className="w-2 h-2 rounded-full bg-amber-500"></div>
              <div className="w-12 h-px bg-gradient-to-l from-transparent to-amber-500"></div>
            </div>
          </div>

          {/* Categories */}
          <div className="flex flex-wrap gap-2 justify-center mb-8">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-5 py-2.5 rounded-full text-sm font-semibold transition border ${
                  selectedCategory === cat
                    ? "bg-gradient-to-r from-stone-800 to-stone-900 text-amber-300 border-amber-600 shadow-lg shadow-stone-900/20"
                    : "bg-white text-stone-700 border-stone-200 hover:border-amber-400 hover:text-amber-700"
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          <div className="flex flex-wrap items-center justify-between gap-3 mb-8">
            <div className="text-sm text-stone-600">
              عرض <span className="font-bold text-amber-700">{filteredProducts.length}</span> منتج
            </div>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="px-4 py-2 rounded-full border border-stone-200 bg-white text-sm focus:border-amber-400 outline-none cursor-pointer"
            >
              <option value="default">ترتيب افتراضي</option>
              <option value="price-asc">السعر: من الأقل للأعلى</option>
              <option value="price-desc">السعر: من الأعلى للأقل</option>
            </select>
          </div>

          {/* Products Grid */}
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
            {filteredProducts.map((p) => (
              <ProductCard
                key={p.id}
                product={p}
                onAddToCart={addToCart}
                onBuyNow={(p) => setOrderProduct(p)}
                onQuickView={(p) => setQuickViewProduct(p)}
              />
            ))}
          </div>

          {filteredProducts.length === 0 && (
            <div className="text-center py-20">
              <div className="text-6xl mb-4">🔍</div>
              <p className="text-xl text-stone-500">لا توجد منتجات مطابقة</p>
            </div>
          )}
        </div>
      </section>

      {/* Testimonials / Trust */}
      <section className="bg-gradient-to-br from-[#1a0f1a] to-[#2a1810] text-white py-20">
        <div className="max-w-5xl mx-auto px-4 text-center">
          <p className="text-amber-400 text-xs tracking-[0.4em] mb-3">TESTIMONIALS</p>
          <h3 className="text-3xl md:text-5xl font-serif font-bold mb-4">آراء عملائنا الكرام</h3>
          <div className="flex items-center justify-center gap-3 mb-12">
            <div className="w-12 h-px bg-gradient-to-r from-transparent to-amber-500"></div>
            <div className="text-amber-500">✦</div>
            <div className="w-12 h-px bg-gradient-to-l from-transparent to-amber-500"></div>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {[
              { name: "أمينة من الجزائر", text: "خدمة ممتازة وجودة منتجات رائعة. التوصيل كان سريع جداً!", rate: 5 },
              { name: "محمد من وهران", text: "أسعار منافسة ومنتجات أصلية. سأطلب مرة أخرى بدون شك.", rate: 5 },
              { name: "سارة من قسنطينة", text: "تجربة تسوق فاخرة من البداية للنهاية. أنصح الجميع!", rate: 5 },
            ].map((r, i) => (
              <div key={i} className="bg-white/5 backdrop-blur-xl border border-amber-500/20 rounded-2xl p-6 hover:border-amber-400/50 transition">
                <div className="flex justify-center gap-1 mb-3 text-amber-400">
                  {Array.from({ length: r.rate }).map((_, j) => <span key={j}>★</span>)}
                </div>
                <p className="text-stone-300 leading-relaxed mb-4 italic">"{r.text}"</p>
                <p className="text-amber-300 font-semibold text-sm">— {r.name}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-[#0f0a0f] text-stone-300">
        <div className="max-w-7xl mx-auto px-4 py-16 grid md:grid-cols-4 gap-10">
          <div className="md:col-span-1">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 rounded-full bg-gradient-to-br from-amber-400 via-amber-600 to-amber-800 flex items-center justify-center shadow-lg shadow-amber-500/30">
                <span className="text-white font-serif text-xl font-bold">V</span>
              </div>
              <div>
                <h4 className="text-xl font-serif font-bold tracking-[0.25em] text-white">VELORIA</h4>
                <p className="text-[10px] tracking-[0.5em] text-amber-500 -mt-1">HOME</p>
              </div>
            </div>
            <p className="text-stone-400 text-sm leading-relaxed">
              متجركم الفاخر الأول في الجزائر. نوفر لكم أرقى المنتجات بأفضل الأسعار مع توصيل سريع لكل الولايات.
            </p>
          </div>

          <div>
            <h5 className="font-serif font-bold mb-4 text-amber-400 tracking-wider">الفئات</h5>
            <ul className="space-y-3 text-sm">
              {categories.slice(1, 6).map((c) => (
                <li key={c}>
                  <button
                    onClick={() => {
                      setSelectedCategory(c);
                      document.getElementById("products")?.scrollIntoView({ behavior: "smooth" });
                    }}
                    className="hover:text-amber-400 transition flex items-center gap-2 group"
                  >
                    <span className="text-amber-600 group-hover:translate-x-1 transition">←</span>
                    {c}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h5 className="font-serif font-bold mb-4 text-amber-400 tracking-wider">روابط سريعة</h5>
            <ul className="space-y-3 text-sm">
              <li><a href="#products" className="hover:text-amber-400 transition">جميع المنتجات</a></li>
              <li><button onClick={() => setSelectedCategory("Promotion")} className="hover:text-amber-400 transition">العروض الحصرية</button></li>
              <li><button onClick={() => setIsCartOpen(true)} className="hover:text-amber-400 transition">سلة المشتريات</button></li>
              <li><a href={`https://wa.me/${WHATSAPP_NUMBER}`} target="_blank" rel="noreferrer" className="hover:text-amber-400 transition">اتصل بنا</a></li>
            </ul>
          </div>

          <div>
            <h5 className="font-serif font-bold mb-4 text-amber-400 tracking-wider">تواصل معنا</h5>
            <ul className="space-y-3 text-sm">
              <li className="flex items-center gap-2">📞 <a href="tel:0559093125" className="hover:text-amber-400">0559093125</a></li>
              <li className="flex items-center gap-2">💬 <a href={`https://wa.me/${WHATSAPP_NUMBER}`} target="_blank" rel="noreferrer" className="hover:text-amber-400">واتساب</a></li>
              <li className="flex items-center gap-2">🚚 توصيل لكل الولايات 58</li>
              <li className="flex items-center gap-2">💳 الدفع عند الاستلام</li>
            </ul>
          </div>
        </div>

        <div className="border-t border-amber-900/30 py-6 text-center text-stone-500 text-xs tracking-wider">
          © 2026 <span className="text-amber-500 font-serif">VELORIA HOME</span> — جميع الحقوق محفوظة
        </div>
      </footer>

      {/* Floating WhatsApp Button */}
      <a
        href={`https://wa.me/${WHATSAPP_NUMBER}`}
        target="_blank"
        rel="noreferrer"
        className="fixed bottom-6 left-6 z-30 w-14 h-14 rounded-full bg-green-500 hover:bg-green-600 text-white shadow-2xl flex items-center justify-center transition hover:scale-110 group"
      >
        <svg width="28" height="28" viewBox="0 0 24 24" fill="currentColor">
          <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.297-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
        </svg>
        <span className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 rounded-full animate-ping"></span>
        <span className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 rounded-full"></span>
      </a>

      {/* Cart Drawer */}
      {isCartOpen && (
        <CartDrawer
          cart={cart}
          onClose={() => setIsCartOpen(false)}
          onRemove={removeFromCart}
          onUpdateQty={updateQty}
          onCheckout={() => {
            // Use the first product but pass full cart
            if (cart.length > 0) {
              setIsCartOpen(false);
              setOrderProduct({ ...cart[0], _isCart: true } as any);
            }
          }}
          total={cartTotal}
        />
      )}

      {/* Order Modal */}
      {orderProduct && (
        <OrderModal
          product={orderProduct}
          cart={(orderProduct as any)._isCart ? cart : null}
          onClose={() => setOrderProduct(null)}
        />
      )}

      {/* Quick View Modal */}
      {quickViewProduct && (
        <QuickViewModal
          product={quickViewProduct}
          onClose={() => setQuickViewProduct(null)}
          onAddToCart={(p) => {
            addToCart(p);
            setQuickViewProduct(null);
          }}
          onBuyNow={(p) => {
            setQuickViewProduct(null);
            setOrderProduct(p);
          }}
        />
      )}

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setIsMenuOpen(false)}></div>
          <div className="absolute right-0 top-0 bottom-0 w-80 bg-white p-6 shadow-2xl overflow-y-auto animate-slide-in-right">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-2">
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-amber-400 to-amber-700 flex items-center justify-center">
                  <span className="text-white font-serif font-bold">V</span>
                </div>
                <span className="font-serif font-bold tracking-widest">VELORIA</span>
              </div>
              <button onClick={() => setIsMenuOpen(false)} className="p-2 hover:bg-stone-100 rounded-full">✕</button>
            </div>
            <h3 className="text-sm font-bold mb-3 text-stone-500 tracking-wider">الفئات</h3>
            <div className="space-y-1">
              {categories.map((c) => (
                <button
                  key={c}
                  onClick={() => {
                    setSelectedCategory(c);
                    setIsMenuOpen(false);
                    document.getElementById("products")?.scrollIntoView({ behavior: "smooth" });
                  }}
                  className={`w-full text-right px-4 py-3 rounded-xl font-semibold transition ${
                    selectedCategory === c
                      ? "bg-gradient-to-r from-amber-50 to-amber-100 text-amber-800"
                      : "hover:bg-stone-50 text-stone-700"
                  }`}
                >
                  {c}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

/* ============ Product Card ============ */
function ProductCard({
  product: p,
  onAddToCart,
  onBuyNow,
  onQuickView,
}: {
  product: Product;
  onAddToCart: (p: Product) => void;
  onBuyNow: (p: Product) => void;
  onQuickView: (p: Product) => void;
}) {
  return (
    <div className="group bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-2xl hover:shadow-amber-900/10 transition-all duration-500 border border-stone-100 hover:border-amber-200 flex flex-col">
      <div className="relative overflow-hidden aspect-square bg-gradient-to-br from-stone-50 to-stone-100">
        {p.onSale && (
          <span className="absolute top-3 right-3 z-10 bg-gradient-to-r from-red-500 to-red-600 text-white text-[10px] font-bold px-3 py-1.5 rounded-full shadow-lg tracking-wider">
            تخفيض
          </span>
        )}
        <div className="absolute top-3 left-3 z-10 opacity-0 group-hover:opacity-100 transition">
          <button
            onClick={() => onQuickView(p)}
            className="w-9 h-9 rounded-full bg-white/95 backdrop-blur shadow-lg flex items-center justify-center text-stone-700 hover:bg-amber-500 hover:text-white transition"
            title="عرض سريع"
          >
            <svg width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2">
              <circle cx="8" cy="8" r="6" />
              <path d="M8 5v6M5 8h6" />
            </svg>
          </button>
        </div>
        <img
          src={p.image}
          alt={p.name}
          loading="lazy"
          className="w-full h-full object-cover group-hover:scale-110 transition duration-700"
        />
        <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/60 to-transparent p-3 opacity-0 group-hover:opacity-100 transition translate-y-2 group-hover:translate-y-0 duration-300">
          <button
            onClick={() => onQuickView(p)}
            className="w-full bg-white/95 backdrop-blur text-stone-800 font-bold py-2 rounded-full text-xs hover:bg-amber-500 hover:text-white transition"
          >
            عرض التفاصيل
          </button>
        </div>
      </div>

      <div className="p-4 flex flex-col flex-1">
        <span className="text-[10px] text-amber-700 font-semibold uppercase tracking-[0.2em]">
          {p.category}
        </span>
        <h4 className="font-semibold text-sm md:text-[15px] mt-1.5 line-clamp-2 min-h-[2.5rem] text-stone-800 group-hover:text-amber-800 transition">
          {p.name}
        </h4>
        <div className="mt-2 flex items-baseline gap-2 flex-wrap">
          <span className="text-stone-900 font-bold text-base md:text-lg">
            {formatPrice(p.price)}
          </span>
          {p.oldPrice && (
            <span className="text-xs text-stone-400 line-through">{formatPrice(p.oldPrice)}</span>
          )}
        </div>

        <div className="mt-4 flex gap-2 pt-3 border-t border-stone-100">
          <button
            onClick={() => onBuyNow(p)}
            className="flex-1 bg-gradient-to-r from-stone-900 to-stone-800 hover:from-amber-700 hover:to-amber-900 text-white font-bold text-xs md:text-sm py-2.5 rounded-full transition shadow-md flex items-center justify-center gap-1"
          >
            اشتري الآن
          </button>
          <button
            onClick={() => onAddToCart(p)}
            className="w-10 h-10 bg-amber-50 hover:bg-amber-100 text-amber-700 rounded-full transition flex items-center justify-center"
            title="أضف للسلة"
          >
            <svg width="18" height="18" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M3 3h2l2 13h12l2-8H6" />
              <circle cx="9" cy="20" r="1.5" />
              <circle cx="17" cy="20" r="1.5" />
            </svg>
          </button>
        </div>
      </div>
    </div>
  );
}

/* ============ Quick View Modal ============ */
function QuickViewModal({
  product,
  onClose,
  onAddToCart,
  onBuyNow,
}: {
  product: Product;
  onClose: () => void;
  onAddToCart: (p: Product) => void;
  onBuyNow: (p: Product) => void;
}) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" onClick={onClose}></div>
      <div className="relative bg-white rounded-3xl shadow-2xl max-w-4xl w-full max-h-[90vh] overflow-hidden grid md:grid-cols-2 animate-zoom-in">
        <button
          onClick={onClose}
          className="absolute top-4 left-4 z-10 w-10 h-10 rounded-full bg-white shadow-lg flex items-center justify-center text-stone-700 hover:bg-stone-100"
        >
          ✕
        </button>
        <div className="aspect-square md:aspect-auto bg-gradient-to-br from-stone-50 to-stone-100 overflow-hidden">
          <img src={product.image} alt={product.name} className="w-full h-full object-cover" />
        </div>
        <div className="p-6 md:p-8 flex flex-col overflow-y-auto">
          <span className="text-xs text-amber-700 font-semibold uppercase tracking-[0.3em] mb-2">
            {product.category}
          </span>
          <h3 className="text-2xl md:text-3xl font-serif font-bold text-stone-800 mb-4">
            {product.name}
          </h3>
          <div className="flex items-center gap-1 text-amber-500 mb-4">
            ★★★★★ <span className="text-stone-500 text-sm mr-2">(تقييم ممتاز)</span>
          </div>
          <div className="flex items-baseline gap-3 mb-6">
            <span className="text-3xl font-bold text-stone-900">{formatPrice(product.price)}</span>
            {product.oldPrice && (
              <span className="text-lg text-stone-400 line-through">{formatPrice(product.oldPrice)}</span>
            )}
            {product.onSale && (
              <span className="bg-red-500 text-white text-xs px-2 py-1 rounded-full">تخفيض!</span>
            )}
          </div>

          <ul className="space-y-2 text-sm text-stone-600 mb-6">
            <li className="flex items-center gap-2">✅ منتج أصلي 100%</li>
            <li className="flex items-center gap-2">🚚 توصيل لكل ولايات الجزائر</li>
            <li className="flex items-center gap-2">💳 الدفع عند الاستلام</li>
            <li className="flex items-center gap-2">🛡️ ضمان الجودة</li>
          </ul>

          <div className="flex gap-3 mt-auto">
            <button
              onClick={() => onBuyNow(product)}
              className="flex-1 bg-gradient-to-r from-amber-600 to-amber-800 hover:from-amber-700 hover:to-amber-900 text-white font-bold py-3 rounded-full shadow-lg transition"
            >
              🛒 اشتري الآن
            </button>
            <button
              onClick={() => onAddToCart(product)}
              className="px-6 py-3 border-2 border-stone-800 text-stone-800 hover:bg-stone-800 hover:text-white font-bold rounded-full transition"
            >
              أضف للسلة
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ============ Cart Drawer ============ */
function CartDrawer({
  cart,
  onClose,
  onRemove,
  onUpdateQty,
  onCheckout,
  total,
}: {
  cart: CartItem[];
  onClose: () => void;
  onRemove: (id: number) => void;
  onUpdateQty: (id: number, qty: number) => void;
  onCheckout: () => void;
  total: number;
}) {
  return (
    <div className="fixed inset-0 z-50 flex">
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose}></div>
      <div className="relative ml-auto w-full max-w-md bg-white h-full shadow-2xl flex flex-col animate-slide-in-left">
        <div className="p-5 border-b flex items-center justify-between bg-gradient-to-r from-stone-900 to-stone-800 text-white">
          <h3 className="text-xl font-serif font-bold tracking-wider">سلة المشتريات ({cart.length})</h3>
          <button onClick={onClose} className="p-2 hover:bg-white/10 rounded-full">✕</button>
        </div>
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {cart.length === 0 ? (
            <div className="text-center py-20 text-stone-500">
              <div className="text-6xl mb-3">🛒</div>
              <p className="font-semibold">سلتك فارغة</p>
              <p className="text-xs mt-1">ابدأ التسوق الآن واكتشف مجموعتنا</p>
            </div>
          ) : (
            cart.map((p) => (
              <div key={p.id} className="flex gap-3 bg-stone-50 rounded-2xl p-3">
                <img src={p.image} alt={p.name} className="w-20 h-20 rounded-xl object-cover" />
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-bold line-clamp-2">{p.name}</div>
                  <div className="text-amber-700 font-bold text-sm mt-1">{formatPrice(p.price)}</div>
                  <div className="flex items-center gap-2 mt-2">
                    <button
                      onClick={() => onUpdateQty(p.id, p.quantity - 1)}
                      className="w-7 h-7 bg-white border border-stone-200 rounded-full hover:bg-amber-50"
                    >
                      −
                    </button>
                    <span className="font-bold text-sm w-6 text-center">{p.quantity}</span>
                    <button
                      onClick={() => onUpdateQty(p.id, p.quantity + 1)}
                      className="w-7 h-7 bg-white border border-stone-200 rounded-full hover:bg-amber-50"
                    >
                      +
                    </button>
                  </div>
                </div>
                <button
                  onClick={() => onRemove(p.id)}
                  className="text-red-500 hover:bg-red-50 p-2 rounded-full h-fit"
                >
                  🗑
                </button>
              </div>
            ))
          )}
        </div>
        {cart.length > 0 && (
          <div className="border-t p-5 space-y-3 bg-white">
            <div className="flex justify-between text-sm text-stone-600">
              <span>المجموع الفرعي:</span>
              <span>{formatPrice(total)}</span>
            </div>
            <div className="flex justify-between text-lg font-bold border-t pt-3">
              <span>الإجمالي:</span>
              <span className="text-amber-700">{formatPrice(total)}</span>
            </div>
            <button
              onClick={onCheckout}
              className="w-full bg-gradient-to-r from-amber-600 to-amber-800 hover:from-amber-700 hover:to-amber-900 text-white font-bold py-3.5 rounded-full transition shadow-lg tracking-wider"
            >
              ✅ إتمام الطلب عبر واتساب
            </button>
            <p className="text-xs text-center text-stone-500">سيتم التواصل معك لتأكيد الطلب</p>
          </div>
        )}
      </div>
    </div>
  );
}

/* ============ Order Form Modal => WhatsApp ============ */
function OrderModal({
  product,
  cart,
  onClose,
}: {
  product: Product;
  cart: CartItem[] | null;
  onClose: () => void;
}) {
  const [form, setForm] = useState({
    name: "",
    phone: "",
    wilaya: "",
    commune: "",
    address: "",
    quantity: 1,
    delivery: "home" as "home" | "desk",
    notes: "",
  });
  const [submitted, setSubmitted] = useState(false);

  const subtotal = cart
    ? cart.reduce((s, p) => s + p.price * p.quantity, 0)
    : product.price * form.quantity;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name || !form.phone || !form.wilaya) {
      alert("⚠️ الرجاء ملء جميع الحقول المطلوبة");
      return;
    }

    let productsText = "";
    if (cart) {
      productsText = cart
        .map(
          (p, i) =>
            `${i + 1}. ${p.name}\n   • الكمية: ${p.quantity}\n   • السعر: ${formatPrice(
              p.price * p.quantity
            )}`
        )
        .join("\n\n");
    } else {
      productsText = `${product.name}\n• الكمية: ${form.quantity}\n• السعر: ${formatPrice(
        product.price * form.quantity
      )}`;
    }

    const message = `🛍️ *طلب جديد من VELORIA HOME*
━━━━━━━━━━━━━━━━━━━━

👤 *معلومات العميل:*
• الاسم الكامل: ${form.name}
• الهاتف: ${form.phone}
• الولاية: ${form.wilaya}
• البلدية: ${form.commune || "غير محدد"}
• العنوان: ${form.address || "غير محدد"}

📦 *المنتجات:*
${productsText}

🚚 *نوع التوصيل:* ${form.delivery === "home" ? "توصيل للمنزل 🏠" : "التوصيل لمكتب البريد 🏢"}

💰 *المبلغ الإجمالي:* ${formatPrice(subtotal)}

${form.notes ? `📝 *ملاحظات:*\n${form.notes}\n` : ""}
━━━━━━━━━━━━━━━━━━━━
✅ شكراً لاختياركم VELORIA HOME`;

    const url = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;
    window.open(url, "_blank");
    setSubmitted(true);
    setTimeout(() => onClose(), 3000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 md:p-4">
      <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" onClick={onClose}></div>
      <div className="relative bg-white rounded-3xl shadow-2xl max-w-2xl w-full max-h-[95vh] overflow-hidden flex flex-col animate-zoom-in">
        {/* Header */}
        <div className="bg-gradient-to-r from-stone-900 via-[#2a1810] to-stone-900 text-white p-5 relative">
          <button
            onClick={onClose}
            className="absolute top-4 left-4 w-9 h-9 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center"
          >
            ✕
          </button>
          <p className="text-amber-400 text-xs tracking-[0.3em] mb-1">CHECKOUT</p>
          <h3 className="text-2xl font-serif font-bold tracking-wide">إتمام طلبك</h3>
          <p className="text-stone-300 text-sm mt-1">سيتم إرسال طلبك مباشرة عبر واتساب</p>
        </div>

        {submitted ? (
          <div className="p-12 text-center">
            <div className="w-20 h-20 mx-auto rounded-full bg-green-100 flex items-center justify-center mb-4">
              <svg width="40" height="40" fill="none" stroke="green" strokeWidth="3">
                <path d="M5 12l5 5 10-12" />
              </svg>
            </div>
            <h3 className="text-2xl font-bold mb-2">✨ تم إرسال طلبك بنجاح!</h3>
            <p className="text-stone-600">سيتم التواصل معك عبر واتساب لتأكيد الطلب قريباً</p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto">
            {/* Product summary */}
            <div className="p-5 bg-amber-50/50 border-b">
              {cart ? (
                <div className="space-y-2">
                  <p className="text-xs font-bold text-amber-700 mb-2">المنتجات ({cart.length})</p>
                  {cart.map((p) => (
                    <div key={p.id} className="flex items-center gap-3">
                      <img src={p.image} alt={p.name} className="w-14 h-14 rounded-lg object-cover" />
                      <div className="flex-1 min-w-0">
                        <div className="text-sm font-semibold line-clamp-1">{p.name}</div>
                        <div className="text-xs text-stone-500">الكمية: {p.quantity}</div>
                      </div>
                      <div className="text-amber-700 font-bold text-sm">{formatPrice(p.price * p.quantity)}</div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="flex items-center gap-3">
                  <img src={product.image} alt={product.name} className="w-16 h-16 rounded-xl object-cover" />
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-semibold line-clamp-2">{product.name}</div>
                    <div className="text-amber-700 font-bold mt-1">{formatPrice(product.price)}</div>
                  </div>
                </div>
              )}
            </div>

            <div className="p-5 space-y-4">
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1.5 tracking-wider">
                    الاسم الكامل <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={form.name}
                    onChange={(e) => setForm({ ...form, name: e.target.value })}
                    className="w-full px-4 py-2.5 rounded-xl border border-stone-200 focus:border-amber-500 focus:ring-2 focus:ring-amber-100 outline-none transition"
                    placeholder="محمد أحمد"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1.5 tracking-wider">
                    رقم الهاتف <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="tel"
                    required
                    value={form.phone}
                    onChange={(e) => setForm({ ...form, phone: e.target.value })}
                    className="w-full px-4 py-2.5 rounded-xl border border-stone-200 focus:border-amber-500 focus:ring-2 focus:ring-amber-100 outline-none transition"
                    placeholder="0555 123 456"
                  />
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1.5 tracking-wider">
                    الولاية <span className="text-red-500">*</span>
                  </label>
                  <select
                    required
                    value={form.wilaya}
                    onChange={(e) => setForm({ ...form, wilaya: e.target.value })}
                    className="w-full px-4 py-2.5 rounded-xl border border-stone-200 focus:border-amber-500 focus:ring-2 focus:ring-amber-100 outline-none transition bg-white"
                  >
                    <option value="">اختر الولاية</option>
                    {WILAYAS.map((w, i) => (
                      <option key={i} value={w}>{i + 1}. {w}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1.5 tracking-wider">
                    البلدية
                  </label>
                  <input
                    type="text"
                    value={form.commune}
                    onChange={(e) => setForm({ ...form, commune: e.target.value })}
                    className="w-full px-4 py-2.5 rounded-xl border border-stone-200 focus:border-amber-500 focus:ring-2 focus:ring-amber-100 outline-none transition"
                    placeholder="اسم البلدية"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1.5 tracking-wider">
                  العنوان الكامل
                </label>
                <input
                  type="text"
                  value={form.address}
                  onChange={(e) => setForm({ ...form, address: e.target.value })}
                  className="w-full px-4 py-2.5 rounded-xl border border-stone-200 focus:border-amber-500 focus:ring-2 focus:ring-amber-100 outline-none transition"
                  placeholder="الشارع، الحي..."
                />
              </div>

              {!cart && (
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1.5 tracking-wider">
                    الكمية
                  </label>
                  <div className="flex items-center gap-3">
                    <button
                      type="button"
                      onClick={() => setForm({ ...form, quantity: Math.max(1, form.quantity - 1) })}
                      className="w-10 h-10 rounded-full bg-stone-100 hover:bg-amber-100 font-bold text-lg"
                    >
                      −
                    </button>
                    <span className="w-12 text-center font-bold text-lg">{form.quantity}</span>
                    <button
                      type="button"
                      onClick={() => setForm({ ...form, quantity: form.quantity + 1 })}
                      className="w-10 h-10 rounded-full bg-stone-100 hover:bg-amber-100 font-bold text-lg"
                    >
                      +
                    </button>
                  </div>
                </div>
              )}

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-2 tracking-wider">
                  نوع التوصيل
                </label>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => setForm({ ...form, delivery: "home" })}
                    className={`p-3 rounded-xl border-2 text-sm font-semibold transition ${
                      form.delivery === "home"
                        ? "border-amber-500 bg-amber-50 text-amber-800"
                        : "border-stone-200 hover:border-stone-300"
                    }`}
                  >
                    🏠 توصيل للمنزل
                  </button>
                  <button
                    type="button"
                    onClick={() => setForm({ ...form, delivery: "desk" })}
                    className={`p-3 rounded-xl border-2 text-sm font-semibold transition ${
                      form.delivery === "desk"
                        ? "border-amber-500 bg-amber-50 text-amber-800"
                        : "border-stone-200 hover:border-stone-300"
                    }`}
                  >
                    🏢 مكتب البريد
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1.5 tracking-wider">
                  ملاحظات إضافية
                </label>
                <textarea
                  value={form.notes}
                  onChange={(e) => setForm({ ...form, notes: e.target.value })}
                  rows={2}
                  className="w-full px-4 py-2.5 rounded-xl border border-stone-200 focus:border-amber-500 focus:ring-2 focus:ring-amber-100 outline-none transition resize-none"
                  placeholder="أي معلومة إضافية..."
                />
              </div>

              {/* Total */}
              <div className="bg-gradient-to-r from-amber-50 to-amber-100/50 rounded-2xl p-4 border border-amber-200">
                <div className="flex justify-between items-center">
                  <span className="text-sm font-semibold text-stone-700">المبلغ الإجمالي:</span>
                  <span className="text-2xl font-bold text-amber-700">{formatPrice(subtotal)}</span>
                </div>
                <p className="text-xs text-stone-500 mt-1">💳 الدفع عند الاستلام</p>
              </div>
            </div>

            <div className="p-5 border-t bg-white sticky bottom-0">
              <button
                type="submit"
                className="w-full bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white font-bold py-4 rounded-full transition shadow-lg flex items-center justify-center gap-2 tracking-wider"
              >
                <svg width="22" height="22" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.297-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884"/>
                </svg>
                تأكيد الطلب عبر واتساب
              </button>
              <p className="text-xs text-center text-stone-500 mt-2">
                🔒 معلوماتك محمية ولن يتم مشاركتها
              </p>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}
